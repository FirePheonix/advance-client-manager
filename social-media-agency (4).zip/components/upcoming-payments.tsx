"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Mail } from "lucide-react"
import { getUpcomingPayments } from "@/lib/database"

interface UpcomingPayment {
  id: string
  client: string
  amount: number
  dueDate: string
  status: string
  daysUntilDue: number
}

export function UpcomingPayments() {
  const [payments, setPayments] = useState<UpcomingPayment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadPayments() {
      try {
        const data = await getUpcomingPayments()
        setPayments(data)
      } catch (error) {
        console.error("Error loading upcoming payments:", error)
      } finally {
        setLoading(false)
      }
    }

    loadPayments()
  }, [])

  if (loading) {
    return (
      <Card className="bg-black border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Calendar className="mr-2 h-5 w-5" />
            Upcoming Payments
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse p-3 bg-gray-900 rounded-lg">
                <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-black border-gray-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Calendar className="mr-2 h-5 w-5" />
          Upcoming Payments
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {payments.map((payment) => (
            <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
              <div>
                <p className="text-white font-medium">{payment.client}</p>
                <p className="text-gray-400 text-sm">Due: {payment.dueDate}</p>
              </div>
              <div className="text-right">
                <p className="text-green-400 font-medium">₹{payment.amount}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge
                    variant={payment.status === "overdue" ? "destructive" : "secondary"}
                    className={payment.status === "overdue" ? "bg-red-600" : "bg-yellow-600"}
                  >
                    {payment.status}
                  </Badge>
                  <Button size="sm" variant="ghost" className="text-xs p-1 hover:bg-gray-800">
                    <Mail className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
