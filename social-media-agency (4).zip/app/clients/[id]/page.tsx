"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { KanbanBoard } from "@/components/kanban-board"
import { PaymentTimelineGraph } from "@/components/payment-timeline-graph"
import {
  getClientById,
  getTasksByClient,
  getPaymentsByClient,
  createTask,
  updateTask,
  createPayment,
  type Client,
  type Task,
  type Payment,
} from "@/lib/database"

export default function ClientDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"board" | "timeline">("board")
  const [client, setClient] = useState<Client | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])
  const [paymentEvents, setPaymentEvents] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadClientData()
  }, [params.id])

  async function loadClientData() {
    try {
      const [clientData, clientTasks, clientPayments] = await Promise.all([
        getClientById(params.id),
        getTasksByClient(params.id),
        getPaymentsByClient(params.id),
      ])

      setClient(clientData)
      setTasks(clientTasks)
      setPaymentEvents(clientPayments)
    } catch (error) {
      console.error("Error loading client data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleTaskMove = async (taskId: string, newStatus: Task["status"]) => {
    try {
      await updateTask(taskId, { status: newStatus })
      setTasks((prev) => prev.map((task) => (task.id === taskId ? { ...task, status: newStatus } : task)))
    } catch (error) {
      console.error("Error updating task:", error)
    }
  }

  const handleAddTask = async (taskData: any) => {
    try {
      const newTask = await createTask({
        client_id: params.id, // Use snake_case
        title: taskData.title,
        description: taskData.description,
        priority: taskData.priority,
        platform: taskData.platform,
        start_date: taskData.start_date, // Use snake_case
        end_date: taskData.end_date, // Use snake_case
        assignees: taskData.assignees,
        status: taskData.status,
        comments_count: 0, // Use snake_case
      })
      setTasks((prev) => [...prev, newTask])
    } catch (error) {
      console.error("Error adding task:", error)
    }
  }

  const handleAddPost = async (post: { date: string; platform: string; count: number; amount?: number }) => {
    try {
      const newPayment = await createPayment({
        client_id: params.id, // Use snake_case
        amount: post.amount || 0,
        payment_date: post.date, // Use snake_case
        status: "completed",
        type: "post",
        post_count: post.count, // Use snake_case
        platform_breakdown: { [post.platform]: post.count }, // Use snake_case
        description: `${post.count} ${post.platform} posts`,
      })

      setPaymentEvents((prev) =>
        [...prev, newPayment].sort((a, b) => new Date(a.payment_date).getTime() - new Date(b.payment_date).getTime()),
      )
    } catch (error) {
      console.error("Error adding post:", error)
    }
  }

  const handleAddPayment = async (payment: { date: string; amount: number; description: string }) => {
    try {
      const newPayment = await createPayment({
        client_id: params.id, // Use snake_case
        amount: payment.amount,
        payment_date: payment.date, // Use snake_case
        status: "completed",
        type: "payment",
        description: payment.description,
      })

      setPaymentEvents((prev) =>
        [...prev, newPayment].sort((a, b) => new Date(a.payment_date).getTime() - new Date(b.payment_date).getTime()),
      )
    } catch (error) {
      console.error("Error adding payment:", error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white">Loading client data...</div>
      </div>
    )
  }

  if (!client) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white">Client not found</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="text-gray-300 hover:text-white hover:bg-gray-900"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-white">{client.name}</h1>
            <p className="text-gray-400 mt-1">Project Management & Timeline</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant={activeTab === "board" ? "default" : "outline"}
            onClick={() => setActiveTab("board")}
            className={
              activeTab === "board" ? "bg-white text-black" : "bg-black border-gray-800 text-white hover:bg-gray-900"
            }
          >
            Board
          </Button>
          <Button
            variant={activeTab === "timeline" ? "default" : "outline"}
            onClick={() => setActiveTab("timeline")}
            className={
              activeTab === "timeline" ? "bg-white text-black" : "bg-black border-gray-800 text-white hover:bg-gray-900"
            }
          >
            Timeline
          </Button>
        </div>
      </div>

      {activeTab === "board" ? (
        <KanbanBoard clientName={client.name} tasks={tasks} onTaskMove={handleTaskMove} onAddTask={handleAddTask} />
      ) : (
        <PaymentTimelineGraph
          client={client}
          events={paymentEvents}
          onAddPost={handleAddPost}
          onAddPayment={handleAddPayment}
        />
      )}
    </div>
  )
}
