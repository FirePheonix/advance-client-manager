"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Plus, Search, DollarSign, Calendar, User } from "lucide-react"
import { AddTeamMemberDialog } from "@/components/add-team-member-dialog"
import { getTeamMembers, createTeamMember, type TeamMember } from "@/lib/database"

export default function TeamsPage() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)

  useEffect(() => {
    loadTeamMembers()
  }, [])

  async function loadTeamMembers() {
    try {
      const data = await getTeamMembers()
      setTeamMembers(data)
    } catch (error) {
      console.error("Error loading team members:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredMembers = teamMembers.filter(
    (member) =>
      member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.role.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddMember = async (memberData: any) => {
    try {
      const newMember = await createTeamMember(memberData)
      setTeamMembers([newMember, ...teamMembers])
      setShowAddDialog(false)
    } catch (error) {
      console.error("Error adding team member:", error)
    }
  }

  const totalMonthlySalaries = teamMembers.reduce((sum, member) => sum + Number(member.salary), 0)

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white">Teams</h1>
            <p className="text-gray-400 mt-2">Manage your team members, their tasks, and payments</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="bg-black border-gray-800">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-700 rounded w-1/2 mb-2"></div>
                  <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Teams</h1>
          <p className="text-gray-400 mt-2">Manage your team members, their tasks, and payments</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)} className="bg-white text-black hover:bg-gray-200">
          <Plus className="mr-2 h-4 w-4" />
          Add Team Member
        </Button>
      </div>

      {/* Team Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-black border-gray-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Total Team Members</CardTitle>
            <User className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{teamMembers.length}</div>
            <p className="text-xs text-blue-400 mt-1">Active members</p>
          </CardContent>
        </Card>

        <Card className="bg-black border-gray-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Monthly Salaries</CardTitle>
            <DollarSign className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">₹{totalMonthlySalaries.toLocaleString()}</div>
            <p className="text-xs text-green-400 mt-1">Total monthly cost</p>
          </CardContent>
        </Card>

        <Card className="bg-black border-gray-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-300">Average Salary</CardTitle>
            <Calendar className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              ₹{teamMembers.length > 0 ? Math.round(totalMonthlySalaries / teamMembers.length).toLocaleString() : 0}
            </div>
            <p className="text-xs text-purple-400 mt-1">Per team member</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search team members..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-black border-gray-800 text-white placeholder-gray-400"
          />
        </div>
      </div>

      {/* Team Members Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredMembers.map((member) => (
          <Card key={member.id} className="bg-black border-gray-800">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-white">{member.name}</CardTitle>
                  <p className="text-gray-400 mt-1">{member.role}</p>
                </div>
                <Badge variant="default" className="bg-green-600">
                  {member.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Contact Info */}
              <div className="space-y-1">
                <p className="text-sm text-gray-300">{member.email}</p>
                {member.phone && <p className="text-sm text-gray-300">{member.phone}</p>}
              </div>

              {/* Payment Info */}
              <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                <div>
                  <p className="text-sm text-gray-300">Monthly Salary</p>
                  <p className="text-lg font-bold text-green-400">₹{Number(member.salary).toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-300">Payment Date</p>
                  <p className="text-sm text-white">{member.payment_date}</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 bg-black border-gray-700 text-white hover:bg-gray-900"
                >
                  View Details
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 bg-black border-gray-700 text-white hover:bg-gray-900"
                >
                  Edit
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <AddTeamMemberDialog open={showAddDialog} onOpenChange={setShowAddDialog} onAddMember={handleAddMember} />
    </div>
  )
}
