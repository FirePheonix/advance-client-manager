"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Phone, Mail, Calendar, DollarSign } from "lucide-react"
import { AddClientDialog } from "@/components/add-client-dialog"
import { getClients, createClient, type Client } from "@/lib/database"
import Link from "next/link"

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)

  useEffect(() => {
    loadClients()
  }, [])

  async function loadClients() {
    try {
      const data = await getClients()
      setClients(data)
    } catch (error) {
      console.error("Error loading clients:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddClient = async (clientData: any) => {
    try {
      const newClient = await createClient(clientData)
      setClients([newClient, ...clients])
      setShowAddDialog(false)
    } catch (error) {
      console.error("Error adding client:", error)
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white">Clients</h1>
            <p className="text-gray-400 mt-2">Manage your client relationships and projects</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-6 bg-gray-700 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-700 rounded w-1/2"></div>
                  <div className="h-4 bg-gray-700 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Clients</h1>
          <p className="text-gray-400 mt-2">Manage your client relationships and projects</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)} className="bg-white text-black hover:bg-gray-200">
          <Plus className="mr-2 h-4 w-4" />
          Add New Client
        </Button>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search clients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClients.map((client) => (
          <Link key={client.id} href={`/clients/${client.id}`}>
            <Card className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750 transition-colors">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-white">{client.name}</CardTitle>
                  <Badge
                    variant={client.status === "active" ? "default" : "secondary"}
                    className={client.status === "active" ? "bg-green-600" : "bg-yellow-600"}
                  >
                    {client.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-300">
                    <Mail className="mr-2 h-4 w-4" />
                    {client.email}
                  </div>
                  {client.phone && (
                    <div className="flex items-center text-sm text-gray-300">
                      <Phone className="mr-2 h-4 w-4" />
                      {client.phone}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-300">
                    <DollarSign className="mr-2 h-4 w-4" />
                    {client.payment_type === "monthly"
                      ? `₹${client.monthly_rate?.toLocaleString()}/month`
                      : client.payment_type === "weekly"
                        ? `₹${client.weekly_rate?.toLocaleString()}/week`
                        : "Per-post pricing"}
                  </div>
                  {client.next_payment && (
                    <div className="flex items-center text-sm text-gray-300">
                      <Calendar className="mr-2 h-4 w-4" />
                      Next payment: {client.next_payment}
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-1">
                  {client.services.map((service) => (
                    <Badge key={service} variant="outline" className="text-xs border-gray-600 text-gray-300">
                      {service}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <AddClientDialog open={showAddDialog} onOpenChange={setShowAddDialog} onAddClient={handleAddClient} />
    </div>
  )
}
