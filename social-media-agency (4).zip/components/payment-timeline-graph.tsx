"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Plus } from "lucide-react"
import { AddPostToTimelineDialog } from "@/components/add-post-to-timeline-dialog"

interface PaymentEvent {
  date: string
  amount?: number
  postCount?: number
  platformBreakdown?: Record<string, number>
  type: "payment" | "posts" | "reminder"
  status: "completed" | "pending" | "overdue"
  description?: string
}

interface PaymentTimelineGraphProps {
  client: {
    name: string
    paymentType: "monthly" | "weekly" | "per-post"
    monthlyRate?: number
    weeklyRate?: number
  }
  events: PaymentEvent[]
  onAddPost?: (post: { date: string; platform: string; count: number; amount?: number }) => void
  onAddPayment?: (payment: { date: string; amount: number; description: string }) => void
}

const platformColors = {
  Instagram: "#E4405F",
  LinkedIn: "#0077B5",
  Twitter: "#1DA1F2",
  Facebook: "#1877F2",
  YouTube: "#FF0000",
  Reddit: "#FF4500",
}

export function PaymentTimelineGraph({ client, events, onAddPost, onAddPayment }: PaymentTimelineGraphProps) {
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [hoveredDate, setHoveredDate] = useState<string | null>(null)
  const [hoveredData, setHoveredData] = useState<any>(null)

  // Generate last 30 days for the timeline
  const generateDateRange = () => {
    const dates = []
    const today = new Date()
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      dates.push(date.toISOString().split("T")[0])
    }
    return dates
  }

  const dateRange = generateDateRange()

  // Get data for each date
  const getDataForDate = (date: string) => {
    const dayEvents = events.filter((event) => event.date === date)
    const platformBreakdown: Record<string, number> = {}

    dayEvents.forEach((event) => {
      if (event.platformBreakdown) {
        Object.entries(event.platformBreakdown).forEach(([platform, count]) => {
          platformBreakdown[platform] = (platformBreakdown[platform] || 0) + count
        })
      }
    })

    return {
      payments: dayEvents.filter((e) => e.type === "payment").reduce((sum, e) => sum + (e.amount || 0), 0),
      posts: dayEvents.filter((e) => e.type === "posts").reduce((sum, e) => sum + (e.postCount || 0), 0),
      platformBreakdown,
      hasEvent: dayEvents.length > 0,
      events: dayEvents,
    }
  }

  // Calculate max values for scaling
  const maxPayment = Math.max(...events.filter((e) => e.amount).map((e) => e.amount!), 1)
  const maxPosts = Math.max(...events.filter((e) => e.postCount).map((e) => e.postCount!), 1)

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.getDate().toString()
  }

  const getMonthYear = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString("en-US", { month: "short", year: "numeric" })
  }

  const handleMouseEnter = (date: string, data: any) => {
    setHoveredDate(date)
    setHoveredData(data)
  }

  const handleMouseLeave = () => {
    setHoveredDate(null)
    setHoveredData(null)
  }

  const handleAddPost = (post: { date: string; platform: string; count: number; amount?: number }) => {
    onAddPost?.(post)
    setShowAddDialog(false)
  }

  const handleAddPayment = (payment: { date: string; amount: number; description: string }) => {
    onAddPayment?.(payment)
    setShowAddDialog(false)
  }

  // Different visualization based on payment type
  const isPerPostClient = client.paymentType === "per-post"

  return (
    <>
      <Card className="bg-black border-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center">
                <Calendar className="mr-2 h-5 w-5" />
                {isPerPostClient ? "Post Activity Timeline" : "Payment & Activity Timeline"} -{" "}
                {getMonthYear(dateRange[0])}
              </CardTitle>
              <div className="text-sm text-gray-400 mt-1">
                {client.paymentType === "monthly" && `Monthly Rate: ₹${client.monthlyRate}`}
                {client.paymentType === "weekly" && `Weekly Rate: ₹${client.weeklyRate}`}
                {client.paymentType === "per-post" && "Per-post billing - Track individual post performance"}
              </div>
            </div>
            <Button onClick={() => setShowAddDialog(true)} className="bg-white text-black hover:bg-gray-200">
              <Plus className="mr-2 h-4 w-4" />
              Add Entry
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Legend */}
            <div className="flex items-center space-x-6 text-sm flex-wrap">
              {!isPerPostClient && (
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <span className="text-gray-300">Payments</span>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded"></div>
                <span className="text-gray-300">Posts</span>
              </div>
              {isPerPostClient && (
                <div className="flex items-center space-x-4">
                  {Object.entries(platformColors).map(([platform, color]) => (
                    <div key={platform} className="flex items-center space-x-1">
                      <div className="w-2 h-2 rounded" style={{ backgroundColor: color }}></div>
                      <span className="text-gray-400 text-xs">{platform}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Graph Container */}
            <div className="relative">
              {/* Y-axis labels */}
              <div className="absolute left-0 top-0 bottom-0 w-12 flex flex-col justify-between text-xs text-gray-400">
                {isPerPostClient ? (
                  <>
                    <span>{maxPosts}</span>
                    <span>{Math.floor(maxPosts / 2)}</span>
                    <span>0</span>
                  </>
                ) : (
                  <>
                    <span>₹{maxPayment}</span>
                    <span>₹{Math.floor(maxPayment / 2)}</span>
                    <span>₹0</span>
                  </>
                )}
              </div>

              {/* Graph area */}
              <div className="ml-16 relative">
                {/* Grid lines */}
                <div className="absolute inset-0 flex flex-col justify-between">
                  {[0, 1, 2].map((i) => (
                    <div key={i} className="border-t border-gray-800"></div>
                  ))}
                </div>

                {/* Data visualization */}
                <div className="h-48 flex items-end justify-between space-x-1">
                  {dateRange.map((date) => {
                    const data = getDataForDate(date)

                    return (
                      <div key={date} className="flex flex-col items-center space-y-1 flex-1 min-w-0 relative">
                        {/* Bar chart */}
                        <div
                          className="relative w-full max-w-6 h-44 flex flex-col justify-end cursor-pointer"
                          onMouseEnter={() => handleMouseEnter(date, data)}
                          onMouseLeave={handleMouseLeave}
                        >
                          {/* Different visualization for per-post vs regular clients */}
                          {isPerPostClient ? (
                            // Per-post client: Stacked bars by platform
                            <div className="w-full flex flex-col justify-end">
                              {Object.entries(data.platformBreakdown).map(([platform, count], idx) => {
                                const height = (count / maxPosts) * 180
                                const color = platformColors[platform as keyof typeof platformColors] || "#6B7280"
                                return (
                                  <div
                                    key={platform}
                                    className="w-full rounded-t"
                                    style={{
                                      height: `${height}px`,
                                      backgroundColor: color,
                                      marginTop: idx > 0 ? "1px" : "0",
                                    }}
                                  ></div>
                                )
                              })}
                            </div>
                          ) : (
                            // Regular client: Payment and post bars
                            <>
                              {data.payments > 0 && (
                                <div
                                  className="w-full bg-green-500 rounded-t"
                                  style={{ height: `${(data.payments / maxPayment) * 180}px` }}
                                ></div>
                              )}
                              {data.posts > 0 && (
                                <div
                                  className="w-full bg-blue-500 rounded-t"
                                  style={{
                                    height: `${(data.posts / 10) * 180}px`,
                                    marginTop: data.payments > 0 ? "2px" : "0",
                                  }}
                                ></div>
                              )}
                            </>
                          )}

                          {/* Event indicators */}
                          {data.hasEvent && (
                            <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                              <div className="w-2 h-2 rounded-full bg-white opacity-80"></div>
                            </div>
                          )}
                        </div>

                        {/* Date label */}
                        <div className="text-xs text-gray-400 text-center">{formatDate(date)}</div>

                        {/* Tooltip */}
                        {hoveredDate === date && hoveredData && (
                          <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-gray-900 border border-gray-700 rounded-lg p-3 text-xs text-white shadow-lg z-10 min-w-48">
                            <div className="font-medium mb-2">{new Date(date).toLocaleDateString()}</div>

                            {!isPerPostClient && hoveredData.payments > 0 && (
                              <div className="text-green-400 mb-1">Payment: ₹{hoveredData.payments}</div>
                            )}

                            {hoveredData.posts > 0 && (
                              <div className="space-y-1">
                                <div className="text-blue-400">Total Posts: {hoveredData.posts}</div>
                                {Object.entries(hoveredData.platformBreakdown).length > 0 && (
                                  <div className="border-t border-gray-700 pt-1 mt-1">
                                    <div className="text-gray-300 text-xs mb-1">Platform Breakdown:</div>
                                    {Object.entries(hoveredData.platformBreakdown).map(([platform, count]) => (
                                      <div key={platform} className="flex items-center justify-between">
                                        <div className="flex items-center space-x-1">
                                          <div
                                            className="w-2 h-2 rounded"
                                            style={{
                                              backgroundColor:
                                                platformColors[platform as keyof typeof platformColors] || "#6B7280",
                                            }}
                                          ></div>
                                          <span>{platform}:</span>
                                        </div>
                                        <span>{count}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>

                {/* X-axis line */}
                <div className="border-t border-gray-700 mt-2"></div>
              </div>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-gray-800">
              <div className="text-center">
                <div className="text-lg font-bold text-green-400">
                  ₹
                  {events
                    .filter((e) => e.type === "payment" && e.status === "completed")
                    .reduce((sum, e) => sum + (e.amount || 0), 0)}
                </div>
                <div className="text-xs text-gray-400">Total Received</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-blue-400">
                  {events.filter((e) => e.type === "posts").reduce((sum, e) => sum + (e.postCount || 0), 0)}
                </div>
                <div className="text-xs text-gray-400">Total Posts</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-yellow-400">
                  ₹{events.filter((e) => e.status === "pending").reduce((sum, e) => sum + (e.amount || 0), 0)}
                </div>
                <div className="text-xs text-gray-400">Pending</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-red-400">
                  ₹{events.filter((e) => e.status === "overdue").reduce((sum, e) => sum + (e.amount || 0), 0)}
                </div>
                <div className="text-xs text-gray-400">Overdue</div>
              </div>
            </div>

            {/* Platform Performance for Per-Post Clients */}
            {isPerPostClient && (
              <div className="pt-4 border-t border-gray-800">
                <h4 className="text-white font-medium mb-3">Platform Performance</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {Object.entries(platformColors).map(([platform, color]) => {
                    const totalPosts = events.reduce((sum, event) => {
                      return sum + (event.platformBreakdown?.[platform] || 0)
                    }, 0)

                    return (
                      <div key={platform} className="flex items-center justify-between p-2 bg-gray-900 rounded">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 rounded" style={{ backgroundColor: color }}></div>
                          <span className="text-gray-300 text-sm">{platform}</span>
                        </div>
                        <span className="text-white font-medium">{totalPosts}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <AddPostToTimelineDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onAddPost={handleAddPost}
        onAddPayment={handleAddPayment}
      />
    </>
  )
}
